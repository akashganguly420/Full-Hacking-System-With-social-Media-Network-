<?php





$con = mysqli_connect("localhost", "root", "", "social"); //Connection variable

if($con) {
    echo "con suc";

}
else {
    echo "faild";
}

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$messege = $_POST['messege'];


$query = " insert into c_comment (name, email, mobile, messege)
values ('$name', '$email', '$mobile', '$messege') ";

mysqli_query($con, $query);

header("Location: submit.php");







?>