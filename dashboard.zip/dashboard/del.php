<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbcomment";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    /* set the PDO error mode to exception */
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

     /*sql to delete a record*/
     $sql = "DROP TABLE `dbcomment`.`tbl_comments`";
     CREATE TABLE `dbcomment`.`tbl_comments` ( `id` INT NOT NULL , `comment` VARCHAR(256) NOT NULL , `comment_time` VARCHAR(256) NOT NULL , `name` VARCHAR(256) NOT NULL ) ENG

    /*use exec() because no results are returned*/
    $conn->exec($sql);
    echo "scripted Removed From Server deleted successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "
" . $e->getMessage();
    }

$conn = null;
?>