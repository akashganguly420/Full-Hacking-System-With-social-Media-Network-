<?php  
require 'config/config.php';
include("includes/classes/User.php");
include("includes/classes/Post.php");
include("includes/classes/Message.php");
include("includes/classes/Notification.php");


if (isset($_SESSION['username'])) {
	$userLoggedIn = $_SESSION['username'];
	$user_details_query = mysqli_query($con, "SELECT * FROM users WHERE username='$userLoggedIn'");
	$user = mysqli_fetch_array($user_details_query);
}
else {
	header("Location: register.php");
}

?>

<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<head>
	<title>Wel Come to Dark Ely</title>

	<!-- Javascript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="assets/js/bootstrap.js"></script>
	<script src="assets/js/bootbox.min.js"></script>
	<script src="assets/js/demo.js"></script>
	<script src="assets/js/jquery.Jcrop.js"></script>
	<script src="assets/js/jcrop_bits.js"></script>


	<!-- CSS -->
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" href="assets/css/jquery.Jcrop.css" type="text/css" />
</head>
<body>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
HTML CSS JSResult
EDIT ON
.navbar-nav li>span {
    position: relative;
    display: block;
    padding: 10px 15px;
    font-weight:bold;
}

/* adds some margin below the link sets  */
.navbar .dropdown-menu div[class*="col"] {
   margin-bottom:1rem;
}



/* breakpoint and up - mega dropdown styles */
@media screen and (min-width: 767px) {
  
  /* remove the padding from the navbar so the dropdown hover state is not broken */
.navbar {
  padding-top:0px;
  padding-bottom:0px;
}

/* remove the padding from the nav-item and add some margin to give some breathing room on hovers */
.navbar .nav-item {
  padding:.5rem .5rem;
  margin:0 .25rem;
}

  
/* makes the dropdown full width  */
.navbar .dropdown {position:static;}

  
.navbar .dropdown-menu {
  width:100%;
  left:0;
  right:0;
/*  height of nav-item  */
  top:45px;
  
  display:block;
  visibility: hidden;
  opacity: 0;
  transition: visibility 0s, opacity 0.3s linear;
  
}
  
 

  
  /* shows the dropdown menu on hover */
.navbar .dropdown:hover .dropdown-menu, .navbar .dropdown .dropdown-menu:hover {
  display:block;
  visibility: visible;
  opacity: 1;
  transition: visibility 0s, opacity 0.3s linear;
}
  
  .navbar .dropdown-menu {
    border: 1px solid rgba(0,0,0,.15);
    background-color: rgb(1, 15, 24);
  }

}


</style>




<nav class="navbar navbar-default">
  <div class="container">
	  
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
		
		
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="users.php">Dark Ely</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hackes <span class="caret"></span></a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">


  <div class="container">
            <div class="row">
              <div class="col col-xs-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Options</span>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="index.php">Post ur Hack</a>
                </li>
              
              </ul>
              </div>
              <!-- /.col  -->
              
              <div class="col col-xs-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Victims</span>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="Victims.html">Victims</a>
                </li>
               
              </ul>
              </div>
              <!-- /.col  -->
              
              <div class="col col-sm-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Remote Hacking</span>  


                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="hackes.php">Victims</a>
                </li>
                
              </ul>
              </div>
              <!-- /.col  -->
              
              
                <div class="col col-xs-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Cooming soon</span>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="prog.php">Courses</a>
                </li>
               
              </ul>
              </div>
              <!-- /.col  -->

              <div class="col col-xs-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Cooming Soon</span>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="hack.php">Courses</a>
                </li>
             
              </ul>
              </div>
              <!-- /.col  -->


              <div class="col col-xs-6 col-md-3">
                <ul class="nav flex-column">
                <li class="nav-item">
                  <span class="nav-link text-bold">Discus With Friends</span>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="index.php">Click Here</a>
                </li>
                
              </ul>
              </div>
              <!-- /.col  -->

             
            
         
          
          <!--  /.container  -->


        </div>
        </li>
      </ul>
      <form class="navbar-form navbar-right">
	  <form class="" action="search.php" method="GET" name="search_form">
				<input type="text" onkeyup="getLiveSearchUsers(this.value, '<?php echo $userLoggedIn; ?>')" name="q" placeholder="Search people" autocomplete="off" id="search_text_input">

				<div class="search_results">
			</div>

			<div class="search_results_footer_empty">
			</div>
					
				</div>

			


			</form>
			<?php
				//Unread messages 
				$messages = new Message($con, $userLoggedIn);
				$num_messages = $messages->getUnreadNumber();

				//Unread notifications 
				$notifications = new Notification($con, $userLoggedIn);
				$num_notifications = $notifications->getUnreadNumber();

				//Unread notifications 
				$user_obj = new User($con, $userLoggedIn);
				$num_requests = $user_obj->getNumberOfFriendRequests();
			?>

		


	</div><!-- /.navbar-collapse -->
	
  </div><!-- /.container-fluid -->
  
</nav>




			


			<style>
    body {
        background-image: linear-gradient(to top, #2121e0 10%, #86377b 40%);
    }
                   
                   section{
                   height:50%;
                   width:100%;
                   position:absolute ;  background:radial-gradient(#333,#000);
                   }
                   .leaf{
                       position:absolute ;
                       width:100%;
                       height:100%;
                       top:0;
                       left:0;
                   }
                   .leaf div{
                   position:absolute ;
                   display:block ;
                   }
                   .leaf div:nth-child(1){
                       left:20%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-2s;
       
                   }
                   .leaf div:nth-child(2){
                       left:70%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-4s;
                   }
                   .leaf div:nth-child(3){
                       left:10%; 
                       animation:fall 20s linear infinite ;
                       animation-delay:-7s;
                       
                   }
                   .leaf div:nth-child(4){
                       left:50%; 
                   animation:fall 18s linear infinite ; 
                   animation-delay:-5s;
                   }
                   .leaf div:nth-child(5){
                       left:85%; 
                       animation:fall 14s linear infinite ;
                       animation-delay:-5s;
                   }
                   .leaf div:nth-child(6){
                       left:15%; 
                       animation:fall 16s linear infinite ;
                       animation-delay:-10s;
                   }
                   .leaf div:nth-child(7){
                       left:90%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-4s;
                   }
       
                   @keyframes fall{
                       0%{
                           opacity:1;
                           top:-10%;
                           transform:translateX (20px) rotate(0deg);
                       }
                       20%{
                           opacity:0.8;
                           transform:translateX (-20px) rotate(45deg);
                       }
                       40%{
       
                           transform:translateX (-20px) rotate(90deg);
                       }
                       60%{
                           
                       transform:translateX (-20px) rotate(135deg); 
                       }
                       80%{
                       
                           transform:translateX (-20px) rotate(180deg);
                       }
                       100%{
                           
                           top:110%;
                           transform:translateX (-20px) rotate(225deg);
                       }
                       }
                   .leaf1{
                       transform: rotateX(180deg);
                   }
              write{
                       position:absolute ;
                       top:40%;
                       width:100%;
                       font-family: 'Courgette', cursive;
                       font-size:4em;
                       text-align:center;
                       transform:translate ;
                       color:#fff;
                       transform:translateY (-50%);
                   }
       
               </style>
               
           <section>
           <write>
                                      Wel come! <br>
                                      <?php echo $user['first_name']; ?>
				</write>
                                    
                              
                                    
                              
                              
                                    
                                    </div>
                            <div class="leaf">
                            <div>  <img src="assets\images\ani\e.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\r.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\l.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\a.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\n.png" height="75px" width="75px"></img></div>
                            
                            
                              
                            </div>
                            
                            <div class="leaf leaf1">
                            <div>  <img src="assets\images\ani\rr.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\e.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\f.png" height="75px" width="75px"></img></div>
                            <div>  <img src="assets\images\ani\eee.png" height="75px" width="75px"></img></div>
                            
                            
                            
                            
                            
                              
							</div>

							
							<sam>
			<a href="<?php echo $userLoggedIn; ?>">
				<?php echo $user['first_name']; ?>
			</a>
			<a href="index.php">
				<i class="fa fa-home fa-lg"></i>
			</a>
			<a href="javascript:void(0);" onclick="getDropdownData('<?php echo $userLoggedIn; ?>', 'message')">
				<i class="fa fa-envelope fa-lg"></i>
				<?php
				if($num_messages > 0)
				 echo '<span class="notification_badge" id="unread_message">' . $num_messages . '</span>';
				?>
			</a>
			<a href="javascript:void(0);" onclick="getDropdownData('<?php echo $userLoggedIn; ?>', 'notification')">
				<i class="fa fa-bell fa-lg"></i>
				<?php
				if($num_notifications > 0)
				 echo '<span class="notification_badge" id="unread_notification">' . $num_notifications . '</span>';
				?>
			</a>
			<a href="requests.php">
				<i class="fa fa-users fa-lg"></i>
				<?php
				if($num_requests > 0)
				 echo '<span class="notification_badge" id="unread_requests">' . $num_requests . '</span>';
				?>
			</a>
			<a href="settings.php">
				<i class="fa fa-cog fa-lg"></i>
			</a>
			<a href="includes/handlers/logout.php">
				<i class="fa fa-sign-out fa-lg"></i>

			</a>
			<div class="dropdown_data_window" style="height:0px; border:none;"></div>
			<input type="hidden" id="dropdown_data_type" value="">
		</sam>
                            
							
						
                            
                            
                            
                            
                              
                            
       
            
       
           
            </section>

			
		


<script>
	$(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready

// breakpoint and up  
$(window).resize(function(){
    if ($(window).width() >= 980){  

      // when you hover a toggle show its dropdown menu
      $(".navbar .dropdown-toggle").hover(function () {
         $(this).parent().toggleClass("show");
         $(this).parent().find(".dropdown-menu").toggleClass("show"); 
       });

        // hide the menu when the mouse leaves the dropdown
      $( ".navbar .dropdown-menu" ).mouseleave(function() {
        $(this).removeClass("show");  
      });
  
        // do something here
    }   
});  
  
  

// document ready  
});

</script>

