<?php


 $con = mysqli_connect("sql105.epizy.com", "epiz_26112776", "kP9vUQ4RkmIO4Kf", "epiz_26112776_submit");

//Declaring variables to prevent errors
$fname = ""; //First name
$mobile = ""; //Last name
$em = "";
$messege ="";



$error_array = array(); //Holds error messages

if(isset($_POST['register_button'])){

	$fname = $_POST['name'];
	$mobile = $_POST['mobile'];
	$em = $_POST['email'];
	$messege =$_POST['messege'];

	if(strlen($fname) > 15 || strlen($fname) < 2) {
	
	 array_push($error_array, "Your  name must be between 2 and 25 characters<br>");
	}

	if(strlen($mobile) > 10 || strlen($mobile) < 10) {
		array_push($error_array, "Your  must be enter 10 Digits number<br>");
	}
	else {
		if(preg_match('/[^0-9]/', $mobile)) {
			array_push($error_array, "Your  number must be number only<br>");
		}
	}

	if(strlen($messege) > 1000 || strlen($messege) < 100) {
		array_push($error_array, "Your  your quesstion ust be 100 to 1000 charecter<br>");
	}
	else {

		$query = " insert into msg (id, name, email, mobile, messege)
		values ('', '$fname', '$em', '$mobile', '$messege') ";


		mysqli_query($con, $query);
		
	
		header("Location: redirect.php");


	}

	





}







	


?>