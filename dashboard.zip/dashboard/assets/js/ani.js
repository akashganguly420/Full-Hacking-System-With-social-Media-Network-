const button = document.querySelector("button");
button.addEventListener("click", e => {
  document.querySelector(".element").classList.toggle("flip-scale-down-diag-2")
})