<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="style3.css">
<link rel="stylesheet" href="assets/css/jquery.Jcrop.css" type="text/css" />
<script src="assets\js\ani.js"></script>

</head>
<title> Hacker Zone</title>
<body>











           
            <div>
                <ul>
                <li><a href="../../users.php">Home</a></li>
                <li><a href="#news">Source Code</a></li>
                <li><a href="#contact">Contact</a></li>
                <li><a href="../../index.php">Discuss-Here</a></li>
                </ul>
            </div>
         

            


            <img src="about-us.jpg" alt="Paris" class="center">

            <br>

            <h2> We are  Devlop Students</h2>
            <br>
            <h2> Without Cost</h2>



            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

            <br>
            <br>
            



            


<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  Powered by <a href="../../users.php"target="_blank">hackers</a>
  </p>
</footer>


</body>
</html>