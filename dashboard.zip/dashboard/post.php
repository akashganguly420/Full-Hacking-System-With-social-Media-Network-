<?php  
include("includes/header.php");

if(isset($_GET['id'])) {
	$id = $_GET['id'];
}
else {
	$id = 0;
}
?>


		<style>
	 


	 .w3-example {
	 background-color: #f1f1f1;
	 padding: 0.01em 16px;
	 margin: 2px 0;
	 box-shadow: 0 2px 4px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12)!important;
	 
   
 
	  }
	 
	 
 
  </style>
 




	<div class="w3-example" id="main_column">
	<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
        	<br>
		<br>
		<br>
		<br>
		<br>
        	<br>
		<br>
        	<br>
		<br>
		
	

		<div class="posts_area">

			<?php 
				$post = new Post($con, $userLoggedIn);
				$post->getSinglePost($id);
			?>

		</div>

	</div>