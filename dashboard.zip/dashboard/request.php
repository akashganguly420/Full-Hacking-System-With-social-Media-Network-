<?php




include 'includes\handlers\coourse_handler.php';
require 'config/config.php';
include("includes/classes/User.php");
include("includes/classes/Post.php");
include("includes/classes/Message.php");
include("includes/classes/Notification.php");


if (isset($_SESSION['username'])) {
	$userLoggedIn = $_SESSION['username'];
	$user_details_query = mysqli_query($con, "SELECT * FROM users WHERE username='$userLoggedIn'");
	$user = mysqli_fetch_array($user_details_query);
}
else {
	header("Location: register.php");
}



$con = mysqli_connect("localhost", "root", "", "submit"); //Connection variable

//Declaring variables to prevent errors
$fname = ""; //First name
$mobile = ""; //Last name
$em = "";
$messege ="";



$error_array = array(); //Holds error messages

if(isset($_POST['register_button'])){

	$fname = $_POST['name'];
	$mobile = $_POST['mobile'];
	$em = $_POST['email'];
	$messege =$_POST['messege'];

	if(strlen($fname) > 15 || strlen($fname) < 2) {
	
	 array_push($error_array, "Your  name must be between 2 and 25 characters<br>");
	}

	if(strlen($mobile) > 10 || strlen($mobile) < 10) {
		array_push($error_array, "Your  must be enter 10 Digits number<br>");
	}
	else {
		if(preg_match('/[^0-9]/', $mobile)) {
			array_push($error_array, "Your  number must be number only<br>");
		}
	}

	if(strlen($messege) > 1000 || strlen($messege) < 20) {
		array_push($error_array, "Your  your quesstion ust be 100 to 1000 charecter<br>");
	}
	else {

		$query = " insert into request (id, name, email, mobile, messege)
		values ('', '$fname', '$em', '$mobile', '$messege') ";


		mysqli_query($con, $query);
		
	
		header("Location: redirect2.php");


	}

	





}







	


?>
<style>

body, html {
	height: 100%;
	
    background-image: linear-gradient(to top, #2121e0 10%, #86377b 40%);

  
	height: 100%;
  
	/* Center and scale the image nicely */
	background-position: center;
	background-repeat: no-repeat;
	background-size: cover;
	background-position-x: right;
  }
  

.sam {
	font-family: 'Bellota-LightItalic', sans-serif;
    position: relative;
    margin-right: auto;
    margin-left: auto;
    top: 7%;
    width: 50%;
    background-color: brown;
	border: solid rgb(18, 243, 10);
	color: rgb(18, 243, 10);
    border-radius: 20px;
    padding: 5px;
	opacity: 0.9;
	text-align: center;
  }

  form {
    text-align: center;
   

}




input[type="submit"] {
    font-family: 'Bellota-BoldItalic', sans-serif;
    background-color: rgb(8, 4, 1);
    border: 1px solid rgb(49, 238, 11);
    padding: 5px 10px 5px 10px;
    border-radius: 20px;
    margin: 5px 0px 5px 0px;
    color: rgb(247, 20, 20);
}

input[type="text"], input[type="email"], input[type="password"], input[type="mobile,"] {
    font-family: 'Bellota-BoldItalic', sans-serif;
    border: 1px solid rgb(14, 248, 25);
    margin-top: 5px;
    width: 70%;
    height: 3%;
    border-radius: 10px;
    text-align: center;
    color: black;
    background-image: linear-gradient(to top, #2121e0 0%, #86377b 0%);
     
    
}

input[type="text"]:hover, input[type="email"]:hover, input[type="password"]:hover {
	border-color: #ec0909;
}

input[type="text2"] {
    font-family: 'Bellota-BoldItalic', sans-serif;
    border: 8px solid rgb(14, 248, 25);
    margin-top: 5px;
    width: 100%;
    height: 20%;
    background-image: linear-gradient(to top, #2121e0 10%, #86377b 40%);
    border-radius: 10px;
    text-align: center;
    color: rgb(173, 8, 223);



}

ul {
	
	margin-left: 0;
	padding: 5%;
	
	list-style-type: none;
	background-color:azure;
	border-radius: 20px;
	
	overflow: hidden;
	font-family: 'Bellota-LightItalic', sans-serif;
    position: relative;
    margin-right: auto;
	margin-left: auto;
	border-radius: 20px;
	padding: 5px;
	opacity: 0.9;
	
	top: 7%;
    width: 100%;
	
  }
  
  li {
	
	float: left;
	background-color:  rgb(145, 207, 243);
	border-radius: 20px;
  }
  
  li a {
	text-align: center;
	margin-left: 8px;
	display: block;
	border: 2px solid rgb(112, 238, 232);
	border-radius: 20px;
	background-color: azure;
	color: black;
	padding: 8px;
	
  }


  


</style>



<div>
                <ul>
                <li><a href="users.php">Home</a></li>
                <li><a href="#news">Source Code</a></li>
                <li><a href="index.php">Discuss-Here</a></li>
				<li><a href="questions.php">Quesstions</a></li>
				<li><a href="#">Answere</a></li>
				<li><a href="#contact">Donate us</a></li>
                <li><a href="assets\aboutus\about.php">About-us</a></li>
                </ul>
            </div>




<br>
       
                    <div class="sam">
                        <h2> Request Here what you want?</h2>
                       
                    </div>

                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>

                        
                    

				<form action="request.php" method="POST">
					<input type="text" name="name" placeholder="Name + Course name" >
                    <br>
                    <?php if(in_array("Your  name must be between 2 and 25 characters<br>", $error_array)) echo "Your  name must be between 2 and 25 characters<br>"; ?>
                    
                    <br>
                    <input type="email" name="email" placeholder="Email" >
                    <br>
                    <input type="text" name="mobile" placeholder="Mob-no" >
                    <br>
                    <?php if(in_array("Your  must be enter 10 Digits number<br>", $error_array)) echo "Your  must be enter 10 Digits number<br>"; ?>
                    <?php if(in_array("YYour  number must be number only<br>", $error_array)) echo "Your  number must be number only<br>"; ?>
                   
                    <br>
                    <input type="text2" name="messege" placeholder="About Course" >
                    <br>
                    
                    <?php if(in_array("Your  your quesstion ust be 100 to 1000 charecter<br>", $error_array)) echo "Your  your quesstion ust be 100 to 1000 charecter<br>"; ?>
                    <br>
                    <input type="submit" name="register_button" value="Request">
                    
				</form>