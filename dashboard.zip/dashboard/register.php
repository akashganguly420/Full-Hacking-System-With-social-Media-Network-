<?php  
require 'config/config.php';
require 'includes/form_handlers/register_handler.php';
require 'includes/form_handlers/login_handler.php';
?>


<html>
<head>
	<title>Wel Come Dark Ely</title>
	<link rel="stylesheet" type="text/css" href="assets/css/register_style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="assets/js/register.js"></script>
</head>
<body>

	<?php  

	if(isset($_POST['register_button'])) {
		echo '
		<script>

		$(document).ready(function() {
			$("#first").hide();
			$("#second").show();
		});

		</script>

		';
	}


	?>


<style>
                   
                   section{
                   height:100%;
                   width:100%;
                   position:absolute ;  background:radial-gradient(#333,#000);
                   }
                   .leaf{
                       position:absolute ;
                       width:100%;
                       height:100%;
                       top:0;
                       left:0;
                   }
                   .leaf div{
                   position:absolute ;
                   display:block ;
                   }
                   .leaf div:nth-child(1){
                       left:20%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-2s;
       
                   }
                   .leaf div:nth-child(2){
                       left:70%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-4s;
                   }
                   .leaf div:nth-child(3){
                       left:10%; 
                       animation:fall 20s linear infinite ;
                       animation-delay:-7s;
                       
                   }
                   .leaf div:nth-child(4){
                       left:50%; 
                   animation:fall 18s linear infinite ; 
                   animation-delay:-5s;
                   }
                   .leaf div:nth-child(5){
                       left:85%; 
                       animation:fall 14s linear infinite ;
                       animation-delay:-5s;
                   }
                   .leaf div:nth-child(6){
                       left:15%; 
                       animation:fall 16s linear infinite ;
                       animation-delay:-10s;
                   }
                   .leaf div:nth-child(7){
                       left:90%; 
                       animation:fall 15s linear infinite ;
                       animation-delay:-4s;
                   }
       
                   @keyframes fall{
                       0%{
                           opacity:1;
                           top:-10%;
                           transform:translateX (20px) rotate(0deg);
                       }
                       20%{
                           opacity:0.8;
                           transform:translateX (-20px) rotate(45deg);
                       }
                       40%{
       
                           transform:translateX (-20px) rotate(90deg);
                       }
                       60%{
                           
                       transform:translateX (-20px) rotate(135deg); 
                       }
                       80%{
                       
                           transform:translateX (-20px) rotate(180deg);
                       }
                       100%{
                           
                           top:110%;
                           transform:translateX (-20px) rotate(225deg);
                       }
                       }
                   .leaf1{
                       transform: rotateX(180deg);
                   }
                   h2{
                       position:absolute ;
                       top:40%;
                       width:100%;
                       font-family: 'Courgette', cursive;
                       font-size:4em;
                       text-align:center;
                       transform:translate ;
                       color:#fff;
                       transform:translateY (-50%);
                   }
       
               </style>
               
           <section>
          
             </div>
     <div class="leaf">
     <div>  <img src="assets\images\ani\e.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\r.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\l.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\a.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\n.png" height="75px" width="75px"></img></div>
     
     
      
     </div>
     
     <div class="leaf leaf1">
     <div>  <img src="assets\images\ani\rr.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\e.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\f.png" height="75px" width="75px"></img></div>
     <div>  <img src="assets\images\ani\eee.png" height="75px" width="75px"></img></div>
     
     
     
     
     
      
     </div>
     
     <div class="leaf leaf2">
     
     
     
      
     </div>
       
            
       
           
            </section>

	<div class="wrapper">

		<div class="login_box">

			<div class="login_header">
				<h1>Dark Ely</h1>
				Join Us To Hack The World
			</div>
			<br>
			<div id="first">

				<form action="register.php" method="POST">
					<input type="email" name="log_email" placeholder="Email Address" value="<?php 
					if(isset($_SESSION['log_email'])) {
						echo $_SESSION['log_email'];
					} 
					?>" required>
					<br>
					<input type="password" name="log_password" placeholder="Password">
					<br>
					<?php if(in_array("Email or password was incorrect<br>", $error_array)) echo  "Email or password was incorrect<br>"; ?>
					<input type="submit" name="login_button" value="Login">
					<br>
					<a href="#" id="signup" class="signup">Hide Login</a>
					
				

				</form>
				
				

			</div>

			<div id="second">
                        
				

					<?php if(in_array("<span style='color: #14C800;'>You're all set! Go ahead and login!</span><br>", $error_array)) echo "<span style='color: #14C800;'>You're all set! Go ahead and login!</span><br>"; ?>
					<a href="#" id="signin" class="signin"><h2>We Are Hide Now</h2></a>
				</form>


					
			</div>

		</div>

	</div>


</body>
</html>